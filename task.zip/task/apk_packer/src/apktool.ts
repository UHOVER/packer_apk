//裁剪图片https://github.com/lovell/sharp
import { exec } from "shelljs"
import * as fs from "fs"
import { appNames, apkName } from "./config"
const sharp = require('sharp')
const iconFolder = 'AndroidIcon'
const iconName = 'ic_launcher.png'
const iconSubFolders = ['mipmap-hdpi', 'mipmap-ldpi', 'mipmap-mdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi']
const sizes = [72, 36, 48, 96, 144, 192]
let errLog: string[] = []
let taskDir: string = ""//task相对目录
apktool()

async function apktool() {
    var path = require("path");
    taskDir = path.resolve('../');
    console.log(taskDir)

    if (!fs.existsSync(`${taskDir}/icons`)) { console.log("icons不存在"); return; }
    if (!fs.existsSync(`${taskDir}/${apkName}`)) { console.log("test不存在"); return; }

    let files = fs.readdirSync(`${taskDir}/icons`)
    if (!files) return

    for (let i = 0; i < files.length; i++) {
        let time0 = Date.now()
        let ic = files[i]
        console.log("\n打包:" + (i + 1) + "===================" + ic)
        if (ic.indexOf('.png') < 0 && ic.indexOf('.jpg') < 0) {
            console.log(ic + "图片格式错误")
            errLog.push(ic + "图片格式错误")
            continue
        }
        let icPrefix = ic.substring(0, ic.indexOf('.'))

        //2.创建目录
        makeIconDir()
        //3.制作icon
        await makeIcon(ic)

        //5.改游戏名
        if (appNames[icPrefix]) {
            //5.改名字
            chgGameName(appNames[icPrefix])
        } else {
            console.log(icPrefix + ' 游戏名字错误：' + appNames[icPrefix])
            errLog.push(icPrefix + ' 游戏名字错误：' + appNames[icPrefix])
            continue
        }

        //6.改包id
        //chgBID(bidPrefix + icPrefix)

        //回包
        pack()

        //签名
        signeApk(icPrefix)

        //7.创建json文件
        // createJson(bidPrefix + icPrefix)
        console.log("成功:" + (i + 1) + " time:" + (Date.now() - time0) / 1000)
    }
    console.error('打包结束，出错的文件如下：')
    console.error(errLog)
}



function makeIconDir() {
    console.log('删除icon文件夹')
    exec(`rm -r ${taskDir}/icons/${iconFolder}`)
    console.log('创建icon文件夹')
    exec(`mkdir ${taskDir}/icons/${iconFolder}`)
    iconSubFolders.forEach(f => {
        exec(`mkdir ${taskDir}/icons/${iconFolder}/${f}`)
    })
}

function makeIcon(name: string) {
    return new Promise<void>(resolve => {
        //拷贝icon到工具工程目录
        exec(`cp ${taskDir}/icons/${name} ./`)

        let count = 0
        function check() {
            if (count === sizes.length) {
                console.log('生成icon完毕')
                //删除工具工程目录icon
                exec(`rm ./${name}`)
                resolve()
            }
        }

        for (let i = 0; i < sizes.length; i++) {
            let s = sizes[i]
            //生成icon
            let corner = s * 15 / 100
            let roundedCorners = Buffer.from(`<svg><rect x="0" y="0" width="${s}" height="${s}" rx="${corner}" ry="${corner}"/></svg>`);

            sharp(name).resize(s, s).overlayWith(roundedCorners, { cutout: true })
                .toFile(`${taskDir}/${apkName}/res/${iconSubFolders[i]}/${iconName}`, function (err: any) {
                    count++
                    check()
                })
        }
    })
}

function chgGameName(name: string) {
    console.log("改名:" + name)
    let xmlFile = `${taskDir}/${apkName}/res/values/strings.xml`
    let buf = fs.readFileSync(xmlFile)
    let str = buf.toString().replace(/app_name\">.+<\//g, `app_name">${name}</`)
    fs.writeFileSync(xmlFile, str)
}

function chgBID(id: string) {
    console.log("改包id:" + id)
    let xmlFile = `${taskDir}/${apkName}/AndroidManifest.xml`
    let buf = fs.readFileSync(xmlFile)
    let str = buf.toString().replace(new RegExp("package=\".+\">\n"), `package=\"${id}\">\n`)
    fs.writeFileSync(xmlFile, str)
}

function pack() {
    console.log('回包')
    exec(`rm ${taskDir}/${apkName}/dist/${apkName}.apk`)
    exec(`cd ${taskDir} && apktool b ${apkName}`)
    console.log(`cd ${taskDir} && apktool b ${apkName}`)
}


function signeApk(name: string) {
    console.log('签名')
    let keyFile = `${taskDir}/apk_packer/key`
    let inFile = `${taskDir}/${apkName}/dist/${apkName}.apk`
    let outFile = `${taskDir}/${name}.apk`
    let cmd = `jarsigner -keystore ${keyFile} -storepass Fengli1. -signedjar ${outFile} ${inFile} key0`
    exec(cmd)
}

function createJson(id: string) {
    // let json = {
    //     "appVer": appVer
    // };
    // fs.writeFileSync(workDir + "/build/outputs/apk/release/" + id + ".json", JSON.stringify(json))
}