import { apkName, sourceDir, apkFile, packerDir } from './config';
import { exec } from "shelljs"
import * as fs from "fs"

let taskCount = 14
let taskContainCnt: number

apkinit()
async function apkinit() {
    //1.初始化
    init()
    //2.创建任务目录
    mkTaskDir()
    //3.分配icon
    distIcon()
    //4.解包分配
    unpackApk()
    //5.分配本工程
    distCode()
}

function init() {
    console.log('初始化')
    let iconCount = 0
    let iconFiles = fs.readdirSync(sourceDir)
    iconFiles.forEach(ic => {
        if (ic.indexOf('.png') >= 0 || ic.indexOf('.jpg') >= 0) {
            iconCount++;
        } else {
            console.log('错误文件:' + ic)
        }
    })
    taskContainCnt = Math.ceil(iconCount / taskCount)
    console.log(`icon共 ${iconCount} 个，分 ${taskCount} 组，每组 ${taskContainCnt}个`)
}

function mkTaskDir() {
    console.log('创建任务目录')
    for (let i = 0; i < taskCount; i++) {
        let taskDir = `${packerDir}/task${i}`
        exec(`rm -r ${taskDir}`)
        exec(`mkdir ${taskDir}`)
    }
}

function distIcon() {
    for (let i = 0; i < taskCount; i++) {
        let taskDir = `${packerDir}/task${i}`
        exec(`mkdir ${taskDir}/icons`)
    }
    let fileIdx = 0
    let taskIdx = 0
    let iconFiles = fs.readdirSync(sourceDir)
    let str = ""
    for (let i = 0; i < iconFiles.length; i++) {
        let ic = iconFiles[i]
        if (ic.indexOf('.png') >= 0 || ic.indexOf('.jpg') >= 0) {
            str += ` ${sourceDir}/${ic} `
            fileIdx++;
            if (fileIdx >= taskContainCnt || i === iconFiles.length - 1) {
                console.log('分配icon:' + taskIdx)
                exec(`cp ${str} ${packerDir}/task${taskIdx}/icons/`)
                str = ""
                fileIdx = 0
                taskIdx++
                continue
            }
        }
    }
}

function unpackApk() {
    console.log('解包')
    exec(`rm -r ${packerDir}/${apkName}`)
    exec(`cd ${packerDir} && apktool d ${apkFile}`)

    for (let i = 0; i < taskCount; i++) {
        let depackDir = `${packerDir}/task${i}/${apkName}`
        exec(`mkdir ${depackDir}`)
        exec(`cp -r ${packerDir}/${apkName}/* ${depackDir}`)
    }
}

function distCode() {
    //拷贝apk_packer工程
    console.log('拷贝apk_packer工程')
    var path = require("path");
    var cur = path.resolve('./');///Users/mac/client-dist/tools/apk_packer
    for (let i = 0; i < taskCount; i++) {
        let taskDir = `${packerDir}/task${i}`
        exec(`mkdir ${taskDir}/apk_packer`)
        exec(`cp -R ${cur}/* ${taskDir}/apk_packer`)
    }
}
